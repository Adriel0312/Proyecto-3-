﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace Pryecto3.Registro
{
    public partial class DatosUsuario : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            if (!Page.IsPostBack) {
                Provincia.Items.Insert(0, "Seleccione una provincia..");
                Provincia.Items[0].Selected = true;
                Provincia.Items[0].Attributes["Disabled"] = "Disabled";

                comboCantHijos.Items.Insert(0, "Seleccione la cantidad de hijos..");
                comboCantHijos.Items[0].Selected = true;
                comboCantHijos.Items[0].Attributes["Disabled"] = "Disabled";
            }
            try
            {
                string a = ((DropDownList)PreviousPage.FindControl("comboboxTipo")).Text;
                if (a == "Cliente")
                {
                    EmpleadoData.Visible = false;
                    clienteData.Visible = true;
                    emailCliente.Text = ((TextBox)PreviousPage.FindControl("emailRegistro")).Text;
                }
                else
                {
                    EmpleadoData.Visible = true;
                    clienteData.Visible = false;
                    emailEmpleado.Text = ((TextBox)PreviousPage.FindControl("emailRegistro")).Text;

                }
            }
            catch { }


        }

        public void DatosUsu()
        {

            string a = ((TextBox)PreviousPage.FindControl("passwordRegistro")).Text;
        }

        protected void Button1_Click(object sender, EventArgs e) { 
        

               
                Response.Redirect("/Mantenimiento/MantenimientoHoteles.aspx");
   
        }

        protected void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        protected void agregarTel_Click(object sender, EventArgs e)
        {
            listaTelefonos.Items.Add(textTelefonos.Text);
            textTelefonos.Text = "";
        }

        protected void eliminarTel_Click(object sender, EventArgs e)
        {
            listaTelefonos.Items.Remove(listaTelefonos.Text);
        }
        protected void agregaridi_Click(object sender, EventArgs e)
        {
            listaIdiomas.Items.Add(textAgregarIdiomas.Text);
            textAgregarIdiomas.Text = "";
        }

        protected void eliminaridi_Click(object sender, EventArgs e)
        {
            listaIdiomas.Items.Remove(listaIdiomas.Text);
        }

        protected void Distrito_TextChanged(object sender, EventArgs e)
        {

        }


        
    }
}
    