﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Windows.Forms;

namespace Pryecto3
{

    public partial class Login : System.Web.UI.Page
    {
       
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        

        protected void Button1_Click(object sender, EventArgs e)
        {
            string a = emailRegistro.Text;
            string b = passwordRegistro.Text;
            string c = comboboxTipo.Text;
          
            //   ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + a + b + "');", true);
            Response.Write(a);
            Response.Write(b);
            Usuario objetoUsuario = new Usuario(a, b, c);
          
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("/Home/HomeSinRegistro.aspx");
        }

        public void emailRegistro_TextChanged(object sender, EventArgs e)
        {

        }
        void ValidaVentana() {
            string c = comboboxTipo.Text;
            if (c == "Empleado") {
                Response.Redirect("DatosUsuarioAdmin.aspx");
            }
            

        }
    }
}