﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pryecto3
{

    public class Usuario
    {
        string idUsuario;
        string contrasenna;
        string tipoUsuario;
        public Usuario(string usuario, string contrasenna, string tipo)
        {
            this.idUsuario = usuario;
            this.contrasenna = contrasenna;
            this.tipoUsuario = tipo;
        }

        string getUsuario()
        {
            return idUsuario;
        }
        string getContrasenna()
        {
            return contrasenna;

        }

        string getTipo()
        {
            return tipoUsuario;
        }

        void crearUsuario()
        {

            if (tipoUsuario == "Cliente")
            {
                 
            }


        }
    }
}
