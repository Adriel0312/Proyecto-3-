﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace  Pryecto3
{ //clase que se encarga de crear un stringconnection para interactuar con la base de datos.
    class ConexionBD
    {
        public static SqlConnection ObtenerConexion()
        {
            SqlConnection Conn = new SqlConnection("Data source= DESKTOP-DE060GT\\SQLADRIEL;Initial Catalog=Turismo; User Id= sa; Password= 1234 ");
            Conn.Open();
            return Conn;
        }



    }



}
