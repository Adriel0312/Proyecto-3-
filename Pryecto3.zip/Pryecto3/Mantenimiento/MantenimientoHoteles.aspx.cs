﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace Pryecto3.Mantenimiento
{
    public partial class MantenimientoHoteles : System.Web.UI.Page
    {
        
        int lastId;
        protected void Page_Load(object sender, EventArgs e)
        {
            
            if (comboOpcion.SelectedValue == "Agregar hotel")
            {
                divForm.Visible = true;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar hotel")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = true;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Editar hotel")
            {
                divForm.Visible = false;
                div2.Visible = true;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Agregar multimedia")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = true;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar multimedia")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = true;

            }
            else if (comboOpcion.SelectedValue == "Agregar redes sociales")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = true;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar redes sociales")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = true;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Agregar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = true;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Editar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = true;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = true;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Agregar Idioma")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = true;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;
            }
            else if (comboOpcion.SelectedValue == "Eliminar Idioma")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = true;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;
            }


            if (listados.SelectedValue == "Hoteles")
            {
                Hoteles.Visible = true;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;
            }
            else if (listados.SelectedValue == "Multimedia")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = true;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Idiomas")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = true;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Habitaciones")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = true;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Redes Sociales")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = true;
            }
            else if (comboOpcion.SelectedValue == "Eliminar hotel")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = true;

            }
            else if (comboOpcion.SelectedValue == "Editar hotel")
            {
                divForm.Visible = false;
                div2.Visible = true;
                div1.Visible = false;

            }
            

            string sqlHotel = null;
            string sqlMultimedia = null;
            string sqlIdioma = null;
            string sqlHabitaciones = null;
            string sqlRedesSociales = null;


            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                

               




                sqlHotel = "select * from Hotel";
                sqlMultimedia = "select * from MultimediaxHotel"; //multimedia



                sqlIdioma = "select * from IdiomaxHotel"; //idiomas



                sqlHabitaciones = "select * from HabitacionesxHotel"; //habitaciones



                sqlRedesSociales = "select * from RedesSocialesxHotel"; //redes 



                SqlCommand Comando = new SqlCommand(sqlHotel, Conn);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(Comando);
                da.Fill(dt);
                Hoteles.DataSource = dt;
                Hoteles.DataBind();


                SqlCommand Comando2 = new SqlCommand(sqlMultimedia, Conn);
                DataTable dt2 = new DataTable();
                SqlDataAdapter da2 = new SqlDataAdapter(Comando2);
                da2.Fill(dt2);
                Multimedia.DataSource = dt2;
                Multimedia.DataBind();


                SqlCommand Comando3 = new SqlCommand(sqlIdioma, Conn);
                DataTable dt3 = new DataTable();
                SqlDataAdapter da3 = new SqlDataAdapter(Comando3);
                da3.Fill(dt3);
                Idiomas.DataSource = dt3;
                Idiomas.DataBind();


                SqlCommand Comando4 = new SqlCommand(sqlHabitaciones, Conn);
                DataTable dt4 = new DataTable();
                SqlDataAdapter da4 = new SqlDataAdapter(Comando4);
                da4.Fill(dt4);
                Habitaciones.DataSource = dt4;
                Habitaciones.DataBind();

                SqlCommand Comando5 = new SqlCommand(sqlRedesSociales, Conn);
                DataTable dt5 = new DataTable();
                SqlDataAdapter da5 = new SqlDataAdapter(Comando5);
                da5.Fill(dt5);
                RedesSociales.DataSource = dt5;
                RedesSociales.DataBind();

            }
        
        }
        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {

        }
        protected void OnSelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Agregar_Click(object sender, EventArgs e)
        {


            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "InsertarHotel";

                int z = Int32.Parse(comboPet.SelectedValue);
                int s = Int32.Parse(comboLey.SelectedValue);
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Nombre", nombre.Text);
                cmd2.Parameters.AddWithValue("@Telefono", telefono.Text);
                cmd2.Parameters.AddWithValue("@SitioWeb", sitioWeb.Text);
                cmd2.Parameters.AddWithValue("@Correo", email.Text);
                cmd2.Parameters.AddWithValue("@Horario", horario.Text);
                cmd2.Parameters.AddWithValue("@Pet", z);
                cmd2.Parameters.AddWithValue("@Ley", s);
                cmd2.Parameters.AddWithValue("@Provincia", comboProvincias.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Canton", canton.Text);
                cmd2.Parameters.AddWithValue("@Distrito", distrito.Text);
                cmd2.Parameters.AddWithValue("@Direccion", direccion.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void comboOpcion_SelectedIndexChanged(object sender, EventArgs e)
        {
           

            if (comboOpcion.SelectedValue == "Agregar hotel")
            {
                divForm.Visible = true;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar hotel")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = true;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Editar hotel")
            {
                divForm.Visible = false;
                div2.Visible = true;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Agregar multimedia")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = true;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar multimedia")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = true;

            }
            else if (comboOpcion.SelectedValue == "Agregar redes sociales")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = true;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar redes sociales")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = true;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Agregar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = true;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Editar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = true;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;

            }
            else if (comboOpcion.SelectedValue == "Eliminar habitaciones")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = true;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;
                
            }
            else if (comboOpcion.SelectedValue == "Agregar Idioma")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = true;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = false;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;
            }
            else if (comboOpcion.SelectedValue == "Eliminar Idioma")
            {
                divForm.Visible = false;
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = false;
                divHabitacionesAgregar.Visible = false;
                divHabitacionesEditar.Visible = false;
                divHabitacionesEliminar.Visible = false;
                divIdiomaEliminar.Visible = true;
                divMultimediaAgregar.Visible = false;
                divRedesAgregar.Visible = false;
                divRedesEliminar.Visible = false;
                divMultimediaEliminar.Visible = false;
            }


        }

        protected void comboOpcion_TextChanged(object sender, EventArgs e)
        {

        }

        protected void comboLey_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            //  Response.Write (comboOpcion.SelectedValue);
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EditarHotel";
                int id = Int32.Parse(TextBox9.Text);
                int z = Int32.Parse(DropDownList1.SelectedValue);
                int s = Int32.Parse(DropDownList2.SelectedValue);
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@id", id);
                cmd2.Parameters.AddWithValue("@Nombre", TextBox1.Text);
                cmd2.Parameters.AddWithValue("@Telefono", TextBox2.Text);
                cmd2.Parameters.AddWithValue("@SitioWeb", TextBox3.Text);
                cmd2.Parameters.AddWithValue("@Correo", TextBox4.Text);
                cmd2.Parameters.AddWithValue("@Horario", TextBox5.Text);
                cmd2.Parameters.AddWithValue("@Pet", z);
                cmd2.Parameters.AddWithValue("@Ley", s);
                cmd2.Parameters.AddWithValue("@Provincia", DropDownList3.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Canton", TextBox6.Text);
                cmd2.Parameters.AddWithValue("@Distrito", TextBox7.Text);
                cmd2.Parameters.AddWithValue("@Direccion", TextBox8.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string sql;
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                sql = "select * from Hotel WHERE id= "+ int.Parse(TextBox9.Text);
                SqlCommand command = new SqlCommand(sql, Conn);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())
                {
                    string combo = dr["Provincia"].ToString();
                    TextBox1.Text = (dr["Nombre"].ToString());
                    TextBox2.Text = (dr["Telefono"].ToString());
                    TextBox3.Text = (dr["SitioWeb"].ToString());
                    TextBox4.Text = (dr["CorreoElectronico"].ToString());
                    TextBox5.Text = (dr["Horario"].ToString());
                    DropDownList3.ClearSelection();
                    DropDownList1.ClearSelection();
                    DropDownList2.ClearSelection();
                    DropDownList3.Items.FindByValue(combo).Selected = true;
                    TextBox6.Text = (dr["Canton"].ToString());
                    TextBox7.Text = (dr["Distrito"].ToString());
                    TextBox8.Text = (dr["Direccion"].ToString());


                }
                else {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "¡No se encontró ese ID en la base de datos!" + "');", true);
                }


            }

        }

        protected void Button3_Click(object sender, EventArgs e)
        {

            //  Response.Write (comboOpcion.SelectedValue);
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EliminarHotel";
                int id = Int32.Parse(TextBox10.Text);
              
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@id", id);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }

        }

        protected void listados_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (listados.SelectedValue == "Hoteles")
            {
                Hoteles.Visible = true;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;



            }
            else if (listados.SelectedValue == "Multimedia")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = true;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Idiomas")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = true;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Habitaciones")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = true;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = false;

            }
            else if (listados.SelectedValue == "Redes Sociales")
            {
                Hoteles.Visible = false;
                Habitaciones.Visible = false;
                Multimedia.Visible = false;
                Idiomas.Visible = false;
                RedesSociales.Visible = true;
            }
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            //  Response.Write (comboOpcion.SelectedValue);
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "InsertarIdiomaxHotel";
                int id = Int32.Parse(TextBox11.Text);

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Hotel", id);
                cmd2.Parameters.AddWithValue("@Idioma", TextBox12.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button6_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EliminarIdiomaxHotel";
            

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Idioma", TextBox20.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo eliminar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "InsertarMultimediaxHotel";
                int id = Int32.Parse(TextBox29.Text);

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Hotel", id);
                cmd2.Parameters.AddWithValue("@Link", TextBox30.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                string proc = "EliminarMultimediaxHotel";
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Link", TextBox13.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo eliminar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button7_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                string proc = "InsertarRedesxHotel";
                int id = Int32.Parse(TextBox14.Text);

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Hotel", id);
                cmd2.Parameters.AddWithValue("@Red", TextBox15.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button8_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                string proc = "EliminarRedesxHotel";
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Red", TextBox16.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo eliminar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button17_Click(object sender, EventArgs e)
        {

            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                string proc = "InsertarHabitacionxHotel";
                float id = float.Parse(TextBox68.Text);
                int Hotelid = int.Parse(TextBox65.Text);

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Hotel", Hotelid);
                cmd2.Parameters.AddWithValue("@Categoria", DropDownList4.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Descripcion",TextBox67.Text);
                cmd2.Parameters.AddWithValue("@Precio", id);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }

        }

        protected void Button18_Click(object sender, EventArgs e)
        {
            string sql;
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                sql = "select * from HabitacionesxHotel WHERE id= " + int.Parse(TextBox74.Text);
                SqlCommand command = new SqlCommand(sql, Conn);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())
                {

                    TextBox17.Text = (dr["Descripcion"].ToString());
                    TextBox18.Text = (dr["Precio"].ToString());
                    TextBox19.Text= (dr["Hotel"].ToString());


                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "¡No se encontró ese ID en la base de datos!" + "');", true);
                }


            }
        }

        protected void Button20_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                int id = int.Parse(TextBox83.Text);
                string proc = "EliminarHabitacionesxHotel";
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@int", id);
                cmd2.Parameters.AddWithValue("@error", "no se pudo eliminar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EditarHabitacionxHotel";
                int idHotel = Int32.Parse(TextBox19.Text);
                int idHabitacion = Int32.Parse(TextBox74.Text);
               
                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@id", idHabitacion);
                cmd2.Parameters.AddWithValue("@Hotel", idHotel);
                cmd2.Parameters.AddWithValue("@Categoria", DropDownList5.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Descripcion", TextBox17.Text);
                cmd2.Parameters.AddWithValue("@Precio", TextBox18.Text);
              
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("MantenimientoHoteles.aspx");
            }
        }

        protected void comboCanton_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        protected void comboProvincias_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void comboOpcion_SelectedIndexChanged1(object sender, EventArgs e)
        {
            
        }
    }
}