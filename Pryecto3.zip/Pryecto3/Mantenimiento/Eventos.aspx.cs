﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace Pryecto3.Mantenimiento
{
    public partial class Eventos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {


            if (comboOpcion2.SelectedValue == "Agregar evento")
            {
                div2.Visible = true;
                div1.Visible = false;
                div3.Visible = false;
             

            }
            else if (comboOpcion2.SelectedValue == "Eliminar evento")
            {
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = true;

            }
            else if (comboOpcion2.SelectedValue == "Editar evento")
            {
                div2.Visible = false;
                div1.Visible = true;
                div3.Visible = false;

            }

            string sqlEventos = null;
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {







                sqlEventos = "select * from  Eventos";
                


                SqlCommand Comando = new SqlCommand(sqlEventos, Conn);
                DataTable dt = new DataTable();
                SqlDataAdapter da = new SqlDataAdapter(Comando);
                da.Fill(dt);
                Eventosgrid.DataSource = dt;
                Eventosgrid.DataBind();



            }
        }

        protected void comboOpcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboOpcion2.SelectedValue == "Agregar evento")
            {
                div2.Visible = true;
                div1.Visible = false;
                div3.Visible = false;


            }
            else if (comboOpcion2.SelectedValue == "Eliminar evento")
            {
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = true;

            }
            else if (comboOpcion2.SelectedValue == "Editar evento")
            {
                div2.Visible = false;
                div1.Visible = true;
                div3.Visible = false;

            }
        }

        protected void Button3_Click(object sender, EventArgs e)
        {

        }

        protected void Agregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "InsertarEvento";

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Nombre", nombreEvento.Text);
                cmd2.Parameters.AddWithValue("@Fecha", TextBox5.Text);
                cmd2.Parameters.AddWithValue("@Descripcion", descripcion.Text);
                cmd2.Parameters.AddWithValue("@NombreContacto", nombreContacto.Text);
                cmd2.Parameters.AddWithValue("@CorreoContacto", mail.Text);
                cmd2.Parameters.AddWithValue("@Telefono", telefono.Text);
                cmd2.Parameters.AddWithValue("@Provincia", comboProvincias.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Canton", canton.Text);
                cmd2.Parameters.AddWithValue("@Distrito", distrito.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Eventos.aspx");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string sql;
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                sql = "select * from Eventos WHERE id= " + int.Parse(TextBox4.Text);
                SqlCommand command = new SqlCommand(sql, Conn);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())
                {
                    
                    TextBox12.Text = (dr["NombreActividad"].ToString());
                    fecha.Text = (dr["Fecha"].ToString());
                    TextBox6.Text = (dr["Descripcion"].ToString());
                    TextBox7.Text = (dr["NombreContacto"].ToString());
                    TextBox8.Text = (dr["CorreoContacto"].ToString());

                 
                    TextBox9.Text = (dr["Telefono"].ToString());
                    TextBox10.Text = (dr["Canton"].ToString());

                    TextBox11.Text = (dr["Distrito"].ToString());



                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "¡No se encontró ese ID en la base de datos!" + "');", true);
                }


            }

        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EliminarEventos";
                int id = Int32.Parse(TextBox13.Text);

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@id", id);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Eventos.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EditarEvento";
                int idEvento = Int32.Parse(TextBox4.Text);
              

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@id", idEvento);
                cmd2.Parameters.AddWithValue("@NombreActividad", TextBox12.Text);
                cmd2.Parameters.AddWithValue("@Fecha", fecha.Text);
                cmd2.Parameters.AddWithValue("@Descripcion", TextBox6.Text);
                cmd2.Parameters.AddWithValue("@NombreContacto", TextBox7.Text);
                cmd2.Parameters.AddWithValue("@CorreoContacto", TextBox8.Text);
                cmd2.Parameters.AddWithValue("@Telefono", TextBox9.Text);
                cmd2.Parameters.AddWithValue("@Provincia", DropDownList1.SelectedValue.ToString());
                cmd2.Parameters.AddWithValue("@Canton", TextBox10.Text);
                cmd2.Parameters.AddWithValue("@Distrito", TextBox11.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Eventos.aspx");
            }
        }
    }
}