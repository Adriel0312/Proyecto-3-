﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using System.Configuration;
using System.Data.SqlClient;
namespace Pryecto3.Mantenimiento
{
    public partial class actividad : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {



                if (comboOpcion2.SelectedValue == "Agregar empresa")
                {
                    div2.Visible = true;
                    div1.Visible = false;
                    div3.Visible = false;


                }
                else if (comboOpcion2.SelectedValue == "Eliminar empresa")
                {
                    div2.Visible = false;
                    div1.Visible = false;
                    div3.Visible = true;

                }
                else if (comboOpcion2.SelectedValue == "Editar empresa")
                {
                    div2.Visible = false;
                    div1.Visible = true;
                    div3.Visible = false;

                }

                string sqlEventos = null;
                using (SqlConnection Conn = ConexionBD.ObtenerConexion())
                {







                    sqlEventos = "select * from  Empresa";



                    SqlCommand Comando = new SqlCommand(sqlEventos, Conn);
                    DataTable dt = new DataTable();
                    SqlDataAdapter da = new SqlDataAdapter(Comando);
                    da.Fill(dt);
                    Eventosgrid.DataSource = dt;
                    Eventosgrid.DataBind();



                }
            }

        protected void comboOpcion_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboOpcion2.SelectedValue == "Agregar empresa")
            {
                div2.Visible = true;
                div1.Visible = false;
                div3.Visible = false;


            }
            else if (comboOpcion2.SelectedValue == "Eliminar empresa") 
            {
                div2.Visible = false;
                div1.Visible = false;
                div3.Visible = true;

            }
            else if (comboOpcion2.SelectedValue == "Editar empresa")
            {
                div2.Visible = false;
                div1.Visible = true;
                div3.Visible = false;

            }
        }

        protected void Agregar_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "InsertarEmpresa";

                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Nombre", nombreEmpresa.Text);
                cmd2.Parameters.AddWithValue("@Contacto", Contacto.Text);
                cmd2.Parameters.AddWithValue("@Telefono", Telefono.Text);
                cmd2.Parameters.AddWithValue("@Correo", correoElectronico.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Empresas.aspx");
            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string sql;
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {
                sql = "select * from Empresa WHERE Correo= " + (TextBox4.Text);
                SqlCommand command = new SqlCommand(sql, Conn);
                SqlDataReader dr = command.ExecuteReader();
                if (dr.Read())
                {

                    TextBox2.Text = (dr["Nombre"].ToString());
                    TextBox3.Text = (dr["Contacto"].ToString());
                    TextBox5.Text = (dr["Descripcion"].ToString());
           



                }
                else
                {
                    ClientScript.RegisterStartupScript(this.GetType(), "myalert", "alert('" + "¡No se encontró ese ID en la base de datos!" + "');", true);
                }


            }
        }

        protected void Button3_Click1(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EliminarEmpresa";


                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@correo", TextBox13.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Empresas.aspx");
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection Conn = ConexionBD.ObtenerConexion())
            {

                string proc = "EditarEmpresas";
                int idEvento = Int32.Parse(TextBox4.Text);


                SqlCommand cmd2 = new SqlCommand(proc, Conn);
                cmd2.CommandType = CommandType.StoredProcedure;
                cmd2.Parameters.AddWithValue("@Correo", TextBox4.Text);
                cmd2.Parameters.AddWithValue("@Contacto", TextBox2.Text);
                cmd2.Parameters.AddWithValue("@Telefono", TextBox3.Text);
                cmd2.Parameters.AddWithValue("@Nombre", TextBox1.Text);
                cmd2.Parameters.AddWithValue("@error", "no se pudo agregar.");
                cmd2.ExecuteNonQuery();
                Response.Redirect("Eventos.aspx");
            }
        }
    }
}